const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  userName: String,
 phone: Number,
 //phoneNo: Number,
  email: String,
edu :String,
  skills: String,
  hobbies: String,
  experience: String,
  image: String
  
});
mongoose.model('users', userSchema);

