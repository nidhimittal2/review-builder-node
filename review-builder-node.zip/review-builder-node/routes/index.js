/*var express = require('express');
var router = express.Router();

var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({extended : true}));
GET home page. 
router.get('/', function(req, res, next) {
  res.render('index');
});

module.exports = router;


*/
const express = require('express');
const router = express.Router();
const ctrlMain = require('../controllers/main');

const ctrlUser = require('../controllers/add');

//const ctrlLogin = require('../controllers/login');

router.get('/', ctrlMain.home);

router.get('/add', ctrlMain.add);
router.get('/view',ctrlMain.view)


router.post('/add',ctrlUser.userCreate);

module.exports = router;
