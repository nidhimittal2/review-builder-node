# review-builder-node
A simple application using node js which builds resume for all the students
