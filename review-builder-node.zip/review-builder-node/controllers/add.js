const mongoose =require('mongoose');
const user=mongoose.model('users');
const userCreate =function(req,res){
    user.create({
     userName : req.body.userName,
phone : req.body.phone,
email : req.body.email,
edu : req.body.education,
skills : req.body.skills,
hobbies : req.body.hobbies,
experience : req.body.experience,
image : req.body.image
    },(err,user) =>{
        if(err){
            res.status(400);
               res.json(err);
        }else{
            res.render('home',{title :'Resume_builder'});
        }
        
    });
};

module.exports={
    userCreate
}
