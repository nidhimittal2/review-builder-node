const mongoose =require('mongoose');
const user=mongoose.model('users');
const userCheck =function(req,res){
	user.countDocuments({rollNo:req.body.rollNo,password:req.body.password},function(err,c){
	      if(c == 0)
		res.render('login',{title :''});
	      else
		res.render('home',{title :''});
	   },(err,user) =>{
        if(err){
            res.status(400);
               res.json(err);
        }else{
          
        }
        
    });
};

module.exports={
    userCheck
}
