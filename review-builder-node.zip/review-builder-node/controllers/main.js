const mongoose =require('mongoose');
//const menus=mongoose.model('menu');
/* GET home page */
var home = function(req, res){
  res.render('home', { title: 'Resume_builder' });
};

var add = function(req, res){
  res.render('addResume', { title: 'Resume_builder' });
};
var view = function(req, res){
  res.render('viewResume', { title: 'Resume_builder' });
};

module.exports = {
  home,
  add,
  view
};
